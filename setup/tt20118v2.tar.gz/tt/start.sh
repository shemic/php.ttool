#! /bin/bash

killall -9 nginx php-cgi

/usr/local/php/bin/spawn-fcgi -a 127.0.0.1 -p 10080 -C 64 -u www -f /usr/local/php/bin/php-cgi
/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf
